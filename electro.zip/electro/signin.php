<?php
$conn=mysqli_connect("localhost","root","","electro");
if($conn)
{
$email=$_POST["Email"];
$password=$_POST["Password"];
$result=mysqli_query($conn,"SELECT * FROM signuptable WHERE Email='$email' and Password='$password'");
}
if(mysqli_fetch_array($result,MYSQLI_ASSOC))
{
header("location:index.html");
}
else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  $emailErr = "Invalid email format"; 
}

else if(($email=='Admin@gmail.com')&&($password=='admin')){
	sleep(3);
header("location:admin.php");
}

else{
 echo "<script>alert('Invalid Mail');</script>";
 
}


?>

